package DBConnections;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBConnections {
    
    private static final String URL = "jdbc:derby://localhost:1527/libraryy";
    private static final String USER = "bookss"; 
    private static final String PASSWORD = "123"; 

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // Method to add a new book
    public static void addBook(String title, String author, String isbn, String category, String status) throws SQLException {
        String sql = "INSERT INTO Books (Title, Author, ISBN, Category, Status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, title);
            pstmt.setString(2, author);
            pstmt.setString(3, isbn);
            pstmt.setString(4, category);
            pstmt.setString(5, status);
            pstmt.executeUpdate();
        }
    }

    // Method to update an existing book
    public static void updateBook(int id, String title, String author, String isbn, String category, String status) throws SQLException {
        String sql = "UPDATE Books SET Title = ?, Author = ?, ISBN = ?, Category = ?, Status = ? WHERE Bookid = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, title);
            pstmt.setString(2, author);
            pstmt.setString(3, isbn);
            pstmt.setString(4, category);
            pstmt.setString(5, status);
            pstmt.setInt(6, id);
            pstmt.executeUpdate();
        }
    }

    // Method to delete a book
    public static void deleteBook(int id) throws SQLException {
        String sql = "DELETE FROM Books WHERE BookID = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }

    // Method to list all books
    public static ResultSet listBooks() throws SQLException {
        String sql = "SELECT * FROM Books";
        Connection conn = getConnection();
        PreparedStatement pstmt = conn.prepareStatement(sql);
        return pstmt.executeQuery();
    }
    
    public static ResultSet AvailableBooks() throws SQLException {
        String sql = "SELECT * FROM Books where status = available";
        Connection conn = getConnection();
        PreparedStatement pstmt = conn.prepareStatement(sql);
        return pstmt.executeQuery();
    }
}
