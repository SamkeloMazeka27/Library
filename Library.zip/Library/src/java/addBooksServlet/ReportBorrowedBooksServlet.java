package addBooksServlet;

import DBConnections.DBConnections;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;

public class ReportBorrowedBooksServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String action = request.getParameter("action");

        List<String[]> results = new ArrayList<>();

        if (email != null && !email.trim().isEmpty()) {
            try (Connection conn = DBConnections.getConnection()) {
                String sql = "SELECT b.Title, u.Name, u.Email, bb.ContactNumber, bb.BorrowDate, bb.ReturnDate " +
                             "FROM BorrowedBooks bb " +
                             "JOIN Books b ON bb.BookID = b.BookID " +
                             "JOIN Users u ON bb.UserEmail = u.Email " +
                             "WHERE u.Email = ?";

                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, email);
                    try (ResultSet rs = stmt.executeQuery()) {
                        while (rs.next()) {
                            results.add(new String[] {
                                rs.getString("Title"),
                                rs.getString("Name"),
                                rs.getString("Email"),
                                rs.getString("ContactNumber"),
                                rs.getString("BorrowDate"),
                                rs.getString("ReturnDate")
                            });
                        }
                    }
                }

                // CSV Export
                if ("Export CSV".equals(action)) {
                    response.setContentType("text/csv");
                    response.setHeader("Content-Disposition", "attachment; filename=\"borrowed_books.csv\"");
                    PrintWriter out = response.getWriter();
                    out.println("Title,Member Name,Email,Contact,Borrow Date,Return Date");
                    for (String[] row : results) {
                        out.println(String.join(",", row));
                    }
                    return;
                }

            } catch (Exception e) {
                throw new ServletException("Error generating borrowed books report", e);
            }
        }

        request.setAttribute("results", results);
        request.getRequestDispatcher("reportBorrowedBooks.jsp").forward(request, response);
    }
}
