package addBooksServlet;

import DBConnections.DBConnections;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

public class SummaryReportServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int totalBooks = 0;
        int totalUsers = 0;
        int borrowedBooks = 0;
        int reservedBooks = 0;

        try (Connection conn = DBConnections.getConnection()) {
            Statement stmt = conn.createStatement();

            ResultSet rs1 = stmt.executeQuery("SELECT COUNT(*) FROM BOOKS");
            if (rs1.next()) totalBooks = rs1.getInt(1);

            ResultSet rs2 = stmt.executeQuery("SELECT COUNT(*) FROM USERS");
            if (rs2.next()) totalUsers = rs2.getInt(1);

            ResultSet rs3 = stmt.executeQuery("SELECT COUNT(*) FROM BORROWEDBOOKS");
            if (rs3.next()) borrowedBooks = rs3.getInt(1);

            ResultSet rs4 = stmt.executeQuery("SELECT COUNT(*) FROM RESERVEDBOOKS");
            if (rs4.next()) reservedBooks = rs4.getInt(1);

            rs1.close(); rs2.close(); rs3.close(); rs4.close();

        } catch (Exception e) {
            throw new ServletException("Error generating summary report", e);
        }

        String action = request.getParameter("action");

        if ("Export CSV".equals(action)) {
            response.setContentType("text/csv");
            response.setHeader("Content-Disposition", "attachment; filename=\"summary_report.csv\"");
            PrintWriter out = response.getWriter();
            out.println("Total Books,Total Users,Borrowed Books,Reserved Books");
            out.printf("%d,%d,%d,%d%n", totalBooks, totalUsers, borrowedBooks, reservedBooks);
            return;
        }

        request.setAttribute("totalBooks", totalBooks);
        request.setAttribute("totalUsers", totalUsers);
        request.setAttribute("borrowedBooks", borrowedBooks);
        request.setAttribute("reservedBooks", reservedBooks);
        request.getRequestDispatcher("summary.jsp").forward(request, response);
    }
}
