package addBooksServlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import DBConnections.DBConnections;

public class DeleteBookServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int bookID = Integer.parseInt(request.getParameter("bookID"));

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DBConnections.getConnection();
            String sql = "DELETE FROM Books WHERE BookID = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, bookID);

            int rows = stmt.executeUpdate();

            if (rows > 0) {
                request.setAttribute("message", "✅ Book with ID " + bookID + " deleted successfully.");
            } else {
                request.setAttribute("message", "⚠️ No book found with ID: " + bookID);
            }

            // Forward to confirmation page
            RequestDispatcher dispatcher = request.getRequestDispatcher("deleteConfirmation.jsp");
            dispatcher.forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "❌ Error deleting book: " + e.getMessage());
            request.getRequestDispatcher("deleteConfirmation.jsp").forward(request, response);
        } finally {
            try { if (stmt != null) stmt.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }
    }
}
