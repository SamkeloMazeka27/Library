package addBooksServlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import DBConnections.DBConnections;

public class UpdateBookServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int bookID = Integer.parseInt(request.getParameter("bookID"));
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnections.getConnection();
            String sql = "SELECT * FROM Books WHERE BookID = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, bookID);
            rs = stmt.executeQuery();

            if (rs.next()) {
                request.setAttribute("bookID", bookID);
                request.setAttribute("title", rs.getString("Title"));
                request.setAttribute("author", rs.getString("Author"));
                request.setAttribute("isbn", rs.getString("ISBN"));
                request.setAttribute("category", rs.getString("Category"));
                request.setAttribute("publisher", rs.getString("Publisher"));
                request.setAttribute("status", rs.getString("Status"));
                RequestDispatcher dispatcher = request.getRequestDispatcher("updateBookForm.jsp");
                dispatcher.forward(request, response);
            } else {
                response.getWriter().println("Book not found.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
            try { if (stmt != null) stmt.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int bookID = Integer.parseInt(request.getParameter("bookID"));
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String isbn = request.getParameter("isbn");
        String category = request.getParameter("category");
        String publisher = request.getParameter("publisher");
        String status = request.getParameter("status");

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DBConnections.getConnection();
            String sql = "UPDATE Books SET Title=?, Author=?, ISBN=?, Category=?, Publisher=?, Status=? WHERE BookID=?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, title);
            stmt.setString(2, author);
            stmt.setString(3, isbn);
            stmt.setString(4, category);
            stmt.setString(5, publisher);
            stmt.setString(6, status);
            stmt.setInt(7, bookID);

            int rows = stmt.executeUpdate();

            if (rows > 0) {
                response.sendRedirect("displayBooks.jsp");
            } else {
                response.getWriter().println("Update failed.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            try { if (stmt != null) stmt.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }
    }
}
