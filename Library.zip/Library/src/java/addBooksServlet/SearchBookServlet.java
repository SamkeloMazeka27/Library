package addBooksServlet;

import DBConnections.DBConnections;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

public class SearchBookServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String query = request.getParameter("query");
        List<Map<String, String>> books = new ArrayList<>();

        try {
            int bookId = Integer.parseInt(query);  // Convert query to int for BookID search

            try (Connection conn = DBConnections.getConnection()) {
                String sql = "SELECT b.*, bb.UserEmail AS BorrowedBy " +
                             "FROM Books b LEFT JOIN BorrowedBooks bb ON b.BookID = bb.BookID " +
                             "WHERE b.BookID = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, bookId);

                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    Map<String, String> book = new HashMap<>();
                    book.put("BookID", String.valueOf(rs.getInt("BookID")));
                    book.put("Title", rs.getString("Title"));
                    book.put("Author", rs.getString("Author"));
                    book.put("Status", rs.getString("Status"));
                    book.put("BorrowedBy", rs.getString("BorrowedBy")); // can be null
                    books.add(book);
                }
            }

        } catch (NumberFormatException e) {
            request.setAttribute("error", "Invalid Book ID. Please enter a number.");
        } catch (Exception e) {
            request.setAttribute("error", "Error retrieving book: " + e.getMessage());
            e.printStackTrace();
        }

        request.setAttribute("books", books);
        RequestDispatcher dispatcher = request.getRequestDispatcher("searchBook.jsp");
        dispatcher.forward(request, response);
    }
}
