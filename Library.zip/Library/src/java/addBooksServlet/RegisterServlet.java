package addBooksServlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.regex.*;
import DBConnections.DBConnections;

public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        // Validate email and password
        if (!isValidEmail(email)) {
            request.setAttribute("error", "Invalid email format. It must include '@'.");
        } else if (!isValidPassword(password)) {
            request.setAttribute("error", "Password must be at least 8 characters long, contain at least one uppercase letter, and one number.");
        } else {
            Connection conn = null;
            PreparedStatement checkStmt = null;
            PreparedStatement insertStmt = null;
            ResultSet rs = null;

            try {
                conn = DBConnections.getConnection();

                // Step 1: Check if email already exists
                String checkSql = "SELECT * FROM Users WHERE Email = ?";
                checkStmt = conn.prepareStatement(checkSql);
                checkStmt.setString(1, email);
                rs = checkStmt.executeQuery();

                if (rs.next()) {
                    request.setAttribute("error", "User already exists with that email.");
                } else {
                    // Step 2: Insert new user
                    String insertSql = "INSERT INTO Users (Name, Email, Password, Role) VALUES (?, ?, ?, ?)";
                    insertStmt = conn.prepareStatement(insertSql);
                    insertStmt.setString(1, name);
                    insertStmt.setString(2, email);
                    insertStmt.setString(3, password); // You should hash this in production!
                    insertStmt.setString(4, role);

                    int rowsInserted = insertStmt.executeUpdate();

                    if (rowsInserted > 0) {
                        request.setAttribute("message", "Registration successful. Please login.");
                    } else {
                        request.setAttribute("error", "Registration failed.");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("error", "Database error: " + e.getMessage());
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (checkStmt != null) checkStmt.close();
                    if (insertStmt != null) insertStmt.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        RequestDispatcher dispatcher = request.getRequestDispatcher("register.jsp");
        dispatcher.forward(request, response);
    }

    // Email must include "@" and a domain
    private boolean isValidEmail(String email) {
        return email != null && email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");
    }

    // Password must be at least 8 characters, include one uppercase and one digit
    private boolean isValidPassword(String password) {
        return password != null && password.matches("^(?=.*[A-Z])(?=.*\\d).{8,}$");
    }
}
