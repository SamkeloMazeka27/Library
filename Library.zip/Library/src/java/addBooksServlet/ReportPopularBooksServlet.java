package addBooksServlet;

import DBConnections.DBConnections;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;

public class ReportPopularBooksServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        List<String[]> results = new ArrayList<>();

        try (Connection conn = DBConnections.getConnection()) {
            String sql = "SELECT b.Title, b.Author, COUNT(bb.BookID) AS TimesBorrowed " +
                         "FROM Books b JOIN BorrowedBooks bb ON b.BookID = bb.BookID " +
                         "GROUP BY b.Title, b.Author " +
                         "ORDER BY TimesBorrowed DESC";

            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {

                while (rs.next()) {
                    results.add(new String[] {
                        rs.getString("Title"),
                        rs.getString("Author"),
                        String.valueOf(rs.getInt("TimesBorrowed"))
                    });
                }
            }

            if ("Export CSV".equals(action)) {
                response.setContentType("text/csv");
                response.setHeader("Content-Disposition", "attachment; filename=\"popular_books.csv\"");
                PrintWriter out = response.getWriter();
                out.println("Title,Author,Times Borrowed");
                for (String[] row : results) {
                    out.println(String.join(",", row));
                }
                return;
            }

        } catch (Exception e) {
            throw new ServletException("Error generating popular books report", e);
        }

        request.setAttribute("results", results);
        request.getRequestDispatcher("reportPopularBooks.jsp").forward(request, response);
    }
}
