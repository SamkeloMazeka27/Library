package addBooksServlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.time.LocalDate;
import DBConnections.DBConnections;

public class BookActionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        int bookId = Integer.parseInt(request.getParameter("bookId"));
        String email = request.getParameter("email");

        Connection conn = null;

        try {
            conn = DBConnections.getConnection();

            if ("borrow".equalsIgnoreCase(action)) {
                String contact = request.getParameter("contact");
                String returnDateStr = request.getParameter("returnDate");
                LocalDate returnDate = LocalDate.parse(returnDateStr);
                LocalDate today = LocalDate.now();

                // ❌ Check if return date is before today
                if (returnDate.isBefore(today)) {
                    request.setAttribute("message", "❌ You cannot select a return date that has already passed.");
                    request.setAttribute("type", "error");
                    request.getRequestDispatcher("message.jsp").forward(request, response);
                    return;
                }

                // Insert into BorrowedBooks
                String sql = "INSERT INTO BorrowedBooks (BookID, UserEmail, ContactNumber, ReturnDate) VALUES (?, ?, ?, ?)";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, bookId);
                    stmt.setString(2, email);
                    stmt.setString(3, contact);
                    stmt.setDate(4, Date.valueOf(returnDate));
                    stmt.executeUpdate();
                }

                // Update book status to Borrowed
                try (PreparedStatement update = conn.prepareStatement("UPDATE Books SET Status='Borrowed' WHERE BookID=?")) {
                    update.setInt(1, bookId);
                    update.executeUpdate();
                }

                request.setAttribute("message", "✅ Book borrowed successfully. Return by: " + returnDate);
                request.setAttribute("type", "success");
                request.getRequestDispatcher("message.jsp").forward(request, response);
                return;
            }

            else if ("reserve".equalsIgnoreCase(action)) {
                String reservationDateStr = request.getParameter("reservationDate");
                LocalDate reserveDate = LocalDate.parse(reservationDateStr);
                LocalDate today = LocalDate.now();
                LocalDate expiryDate = reserveDate.plusDays(3); // valid for 3 days

                // ❌ Check if reservation date is in the past
                if (reserveDate.isBefore(today)) {
                    request.setAttribute("message", "❌ You cannot select a reservation date that has already passed.");
                    request.setAttribute("type", "error");
                    request.getRequestDispatcher("message.jsp").forward(request, response);
                    return;
                }

                // Check if return date of the book allows reservation
                String checkReturnSQL = "SELECT ReturnDate FROM BorrowedBooks WHERE BookID = ?";
                try (PreparedStatement checkStmt = conn.prepareStatement(checkReturnSQL)) {
                    checkStmt.setInt(1, bookId);
                    ResultSet rs = checkStmt.executeQuery();
                    if (rs.next()) {
                        LocalDate actualReturnDate = rs.getDate("ReturnDate").toLocalDate();
                        if (reserveDate.isBefore(actualReturnDate)) {
                            request.setAttribute("message", "⚠️ The book will not be available on " + reserveDate +
                                    ". It is expected to be returned on: " + actualReturnDate);
                            request.setAttribute("type", "error");
                            request.getRequestDispatcher("message.jsp").forward(request, response);
                            return;
                        }
                    }
                }

                // Insert into ReservedBooks
                String insertSql = "INSERT INTO ReservedBooks (BookID, UserEmail, ReservationDate, ExpiryDate) VALUES (?, ?, ?, ?)";
                try (PreparedStatement stmt = conn.prepareStatement(insertSql)) {
                    stmt.setInt(1, bookId);
                    stmt.setString(2, email);
                    stmt.setDate(3, Date.valueOf(reserveDate));
                    stmt.setDate(4, Date.valueOf(expiryDate));
                    stmt.executeUpdate();
                }

                // Update book status to Reserved
                try (PreparedStatement update = conn.prepareStatement("UPDATE Books SET Status='Reserved' WHERE BookID=?")) {
                    update.setInt(1, bookId);
                    update.executeUpdate();
                }

                request.setAttribute("message", "✅ Book reserved successfully. Expires on: " + expiryDate);
                request.setAttribute("type", "success");
                request.getRequestDispatcher("message.jsp").forward(request, response);
                return;
            }

        } catch (Exception e) {
            request.setAttribute("message", "❌ Error: " + e.getMessage());
            request.setAttribute("type", "error");
            request.getRequestDispatcher("message.jsp").forward(request, response);
        } finally {
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }
    }
}
