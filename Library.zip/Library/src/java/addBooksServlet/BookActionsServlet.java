package addBooksServlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import DBConnections.DBConnections;

public class BookActionsServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Connection conn = null;
        PreparedStatement stmt = null;

        // Get the book ID and action (request or reserve) from the form submission
        int bookId = Integer.parseInt(request.getParameter("bookId"));
        String action = request.getParameter("action");

        try {
            conn = DBConnections.getConnection();
            String updateSQL = "";

            // Check what action the user performed
            if ("Request".equals(action)) {
                // Update the book status to "Borrowed"
                updateSQL = "UPDATE Books SET Status = 'Borrowed' WHERE BookID = ?";
            } else if ("Reserve".equals(action)) {
                // Update the book status to "Reserved"
                updateSQL = "UPDATE Books SET Status = 'Reserved' WHERE BookID = ?";
            }

            // Prepare and execute the update query
            stmt = conn.prepareStatement(updateSQL);
            stmt.setInt(1, bookId);
            int rowsUpdated = stmt.executeUpdate();

            // Check if the update was successful
            if (rowsUpdated > 0) {
                request.setAttribute("message", "The book status has been updated successfully.");
            } else {
                request.setAttribute("error", "Error: Could not update the book status.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // Forward the request to a confirmation page or back to the book list
        request.getRequestDispatcher("viewAvailableBooks.jsp").forward(request, response);
    }
}
