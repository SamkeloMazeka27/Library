package addBooksServlet;

import DBConnections.DBConnections;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;

public class ReportBooksPerCategoryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        List<String[]> results = new ArrayList<>();

        try (Connection conn = DBConnections.getConnection()) {
            String sql = "SELECT Category, COUNT(*) AS Total FROM Books GROUP BY Category";
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {

                while (rs.next()) {
                    String category = rs.getString("Category");
                    String total = String.valueOf(rs.getInt("Total"));
                    results.add(new String[] { category, total });
                }
            }

            // Export CSV
            if ("Export CSV".equals(action)) {
                response.setContentType("text/csv");
                response.setHeader("Content-Disposition", "attachment; filename=\"books_by_category.csv\"");
                PrintWriter out = response.getWriter();
                out.println("Category,Total Books");
                for (String[] row : results) {
                    out.println(row[0] + "," + row[1]);
                }
                return;
            }

        } catch (Exception e) {
            throw new ServletException("Error generating category report", e);
        }

        request.setAttribute("results", results);
        request.getRequestDispatcher("reportBooksPerCategory.jsp").forward(request, response);
    }
}
