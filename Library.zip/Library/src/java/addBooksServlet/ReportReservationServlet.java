package addBooksServlet;

import DBConnections.DBConnections;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;

public class ReportReservationServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String from = request.getParameter("from");
        String to = request.getParameter("to");
        String action = request.getParameter("action");

        List<String[]> results = new ArrayList<>();

        if (from != null && to != null) {
            try (Connection conn = DBConnections.getConnection()) {
                String sql = "SELECT b.Title, u.Name, u.Email, rb.ReservationDate " +
                             "FROM ReservedBooks rb " +
                             "JOIN Books b ON rb.BookID = b.BookID " +
                             "JOIN Users u ON rb.UserEmail = u.Email " +
                             "WHERE rb.ReservationDate BETWEEN ? AND ?";

                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setDate(1, java.sql.Date.valueOf(from));
                    stmt.setDate(2, java.sql.Date.valueOf(to));
                    try (ResultSet rs = stmt.executeQuery()) {
                        while (rs.next()) {
                            results.add(new String[] {
                                rs.getString("Title"),
                                rs.getString("Name"),
                                rs.getString("Email"),
                                rs.getString("ReservationDate")
                            });
                        }
                    }
                }

                if ("Export CSV".equals(action)) {
                    response.setContentType("text/csv");
                    response.setHeader("Content-Disposition", "attachment; filename=\"reserved_books.csv\"");
                    PrintWriter out = response.getWriter();
                    out.println("Title,Reserved By,Email,Reservation Date");
                    for (String[] row : results) {
                        out.println(String.join(",", row));
                    }
                    return;
                }

            } catch (Exception e) {
                throw new ServletException("Error generating reservation report", e);
            }
        }

        request.setAttribute("results", results);
        request.getRequestDispatcher("reportReservations.jsp").forward(request, response);
    }
}
