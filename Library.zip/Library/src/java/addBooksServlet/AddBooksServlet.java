package addBooksServlet;

import java.io.*;
import java.nio.file.*;
import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;
import java.sql.*;
import DBConnections.DBConnections;

@MultipartConfig(fileSizeThreshold = 1024 * 1024,    // 1MB
                 maxFileSize = 1024 * 1024 * 10,     // 10MB
                 maxRequestSize = 1024 * 1024 * 15)  // 15MB
public class AddBooksServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String isbn = request.getParameter("isbn");
        String category = request.getParameter("category");
        String publisher = request.getParameter("publisher");
        String status = request.getParameter("status");
        String fileName = null;

        // Handle image upload safely
        try {
            Part imagePart = request.getPart("coverImage");

            if (imagePart != null && imagePart.getSize() > 0) {
                fileName = Paths.get(imagePart.getSubmittedFileName()).getFileName().toString();

                // Save the file to /uploads directory
                String uploadPath = request.getServletContext().getRealPath("/Uploads");
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) uploadDir.mkdirs();

                Path filePath = Paths.get(uploadPath, fileName);
                try (InputStream fileContent = imagePart.getInputStream()) {
                    Files.copy(fileContent, filePath, StandardCopyOption.REPLACE_EXISTING);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error uploading image: " + e.getMessage());
            request.getRequestDispatcher("addBook.jsp").forward(request, response);
            return;
        }

        // Save to database
        try (Connection conn = DBConnections.getConnection()) {
            String sql = "INSERT INTO Books (Title, Author, ISBN, Category, Publisher, Status, Image) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, title);
                stmt.setString(2, author);
                stmt.setString(3, isbn);
                stmt.setString(4, category);
                stmt.setString(5, publisher);
                stmt.setString(6, status);
                stmt.setString(7, fileName); // Save only file name

                int rows = stmt.executeUpdate();
                if (rows > 0) {
                    response.sendRedirect("displayBooks.jsp");
                } else {
                    request.setAttribute("error", "Book not added.");
                    request.getRequestDispatcher("addBook.jsp").forward(request, response);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "SQL Error: " + e.getMessage());
            request.getRequestDispatcher("addBook.jsp").forward(request, response);
        }
    }
}
